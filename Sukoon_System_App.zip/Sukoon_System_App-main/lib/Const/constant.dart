const logo = 'assest/images/logo.png';


//------------------Colors >>
const lightBlue1 = 0xff4CA9DF;
const darkBlue = 0xff292E91;
const lightBlue2  =  0xffE4F2FA;

const gray = 0xffF5F7F9;
const darkGray = 0xffEBEEF2;
const lightGray = 0xffF0F3F6;
const darkerGray = 0xFFB2BBC6;
const darkerGray2 = 0xff8B929A;


